package com.maaki.auto

object Seq {
    /**
     * يولّد الرقم رقم n من الرقم الأساسي.
     * الخانة الأخيرة بتزيد 1 مع كل خطوة (8 ثم 9 ثم 0 ثم 1...)،
     * ولما تكمل لفة كاملة (10 خطوات) الخانة اللي قبلها بتزيد 1، وهكذا.
     * k = عدد الخانات المتغيرة من الآخر. أول 3 خانات ثابتة دائمًا.
     * بيرجّع null لو الرقم الأساسي غلط أو n خرج عن نطاق k خانة.
     */
    fun generate(base: String, k: Int, n: Long): String? {
        if (base.length != 11 || !base.all { it.isDigit() }) return null
        if (k < 1 || k > 8 || n < 0) return null
        var limit = 1L
        repeat(k) { limit *= 10 }
        if (n >= limit) return null
        val d = base.map { it - '0' }.toIntArray()
        var q = n
        for (i in 0 until k) {
            val pos = 10 - i
            d[pos] = (d[pos] + (q % 10).toInt()) % 10
            q /= 10
        }
        return d.joinToString("")
    }
}
