package com.maaki.auto

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RunnerService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val CH = "maaki_run"
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var job: Job? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        when (intent?.action) {
            ACTION_STOP -> { stopAll(); return START_NOT_STICKY }
            else -> {
                startForeground(1, notification("التشغيل شغال"))
                if (job?.isActive != true) {
                    wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "maaki:run").apply { acquire(6 * 60 * 60 * 1000L) }
                    Store.running = true
                    Store.paused = false
                    job = scope.launch {
                        try {
                            runAll(applicationContext)
                        } finally {
                            Store.running = false
                            Bridge.active = null
                            stopAll()
                        }
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun stopAll() {
        job?.cancel()
        Bridge.active = null
        Store.running = false
        if (Store.status != "انتهى") Store.status = "متوقف"
        try { if (wl?.isHeld == true) wl?.release() } catch (_: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "التشغيل", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, CH)
            .setContentTitle("معاكي أوتو")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_phone_call)
            .setOngoing(true)
            .build()
    }

    private fun log(base: String, num: String, outcome: String, text: String) {
        try {
            val t = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val clean = text.replace("\n", " ").replace(",", "،")
            File(filesDir, "results.csv").appendText("$t,$base,$num,$outcome,$clean\n")
        } catch (_: Exception) {}
    }

    private suspend fun CoroutineScope.runAll(ctx: Context) {
        val bases = Store.bases.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val k = Store.digits
        val start = Store.start
        val end = start + Store.count
        val replies = Store.replies.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val noOfferWords = Store.noOffer.split("|").map { it.trim() }.filter { it.isNotEmpty() }

        val handle = Dialer.findHandle(ctx, Store.carrier)
        if (handle == null) {
            Store.status = "ما لقيتش شريحة فودافون"
            return
        }

        var bi = Store.baseIdx
        while (bi < bases.size && isActive) {
            val base = bases[bi]
            var n = Store.seqN
            while (n < end && isActive) {
                while (Store.paused && isActive) { Store.status = "متوقف مؤقتًا"; delay(500) }
                if (!isActive) return

                val num = Seq.generate(base, k, n) ?: break

                // رقم اتبعت قبل كده ومعرفناش نتيجته: نتخطاه ومنكررهوش
                if (Store.pending == num) {
                    Store.pending = ""
                    n++; Store.seqN = n
                    continue
                }

                Store.current = num
                Store.status = "رقم أساسي ${bi + 1}/${bases.size} - $num"
                Store.pending = num

                val session = Session(num, replies, noOfferWords)
                Bridge.active = session
                val ok = Dialer.dial(ctx, Store.template.replace("{N}", num), handle)

                val res: Pair<Outcome, String> = if (!ok) {
                    Outcome.ERROR to "فشل الاتصال"
                } else {
                    withTimeoutOrNull(Store.timeoutSec * 1000L) { session.result.await() }
                        ?: run {
                            UssdService.instance?.back()
                            Outcome.TIMEOUT to "انتهت المهلة"
                        }
                }
                Bridge.active = null

                when (res.first) {
                    Outcome.OFFER_SENT -> Store.sent++
                    Outcome.NO_OFFER -> Store.none++
                    else -> Store.other++
                }
                log(base, num, res.first.name, res.second)

                Store.pending = ""
                n++; Store.seqN = n

                delay(1200)
                delay(Store.delaySec * 1000L)
            }
            bi++
            Store.baseIdx = bi
            Store.seqN = start
        }
        if (isActive) Store.status = "انتهى"
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
