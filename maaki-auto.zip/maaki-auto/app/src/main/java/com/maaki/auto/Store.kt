package com.maaki.auto

import android.content.Context
import android.content.SharedPreferences

/** كل الإعدادات والتقدم محفوظين هنا علشان الاستكمال بعد الإيقاف. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("maaki", Context.MODE_PRIVATE)
        }
    }

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun ps(k: String, v: String) = sp.edit().putString(k, v).apply()
    private fun l(k: String, d: Long) = sp.getLong(k, d)
    private fun pl(k: String, v: Long) = sp.edit().putLong(k, v).apply()

    // ---- الإعدادات ----
    var bases: String
        get() = s("bases", ""); set(v) = ps("bases", v)
    var template: String
        get() = s("template", "*622*1*{N}*5*1*2#"); set(v) = ps("template", v)
    var digits: Int
        get() = l("digits", 2).toInt(); set(v) = pl("digits", v.toLong())
    var start: Long
        get() = l("start", 1); set(v) = pl("start", v)
    var count: Long
        get() = l("count", 10); set(v) = pl("count", v)
    var delaySec: Int
        get() = l("delaySec", 3).toInt(); set(v) = pl("delaySec", v.toLong())
    var timeoutSec: Int
        get() = l("timeoutSec", 40).toInt(); set(v) = pl("timeoutSec", v.toLong())
    var replies: String
        get() = s("replies", "1"); set(v) = ps("replies", v)
    var carrier: String
        get() = s("carrier", "vodafone|فودافون"); set(v) = ps("carrier", v)
    var noOffer: String
        get() = s("noOffer", "لا توجد|لا يوجد|حدث خطأ|حاول مرة|غير متاح|عذرا|عذراً|عفوا|غير مؤهل")
        set(v) = ps("noOffer", v)

    // ---- التقدم ----
    var baseIdx: Int
        get() = l("baseIdx", 0).toInt(); set(v) = pl("baseIdx", v.toLong())
    var seqN: Long
        get() = l("seqN", 1); set(v) = pl("seqN", v)
    /** الرقم اللي اتبعت ومعرفناش نتيجته (مثلاً التطبيق اتقفل): بيتخطى ولا يتكرر. */
    var pending: String
        get() = s("pending", ""); set(v) = ps("pending", v)

    // ---- حالة التشغيل (في الذاكرة) ----
    @Volatile var paused = false
    @Volatile var running = false
    @Volatile var status = "جاهز"
    @Volatile var current = ""
    @Volatile var sent = 0
    @Volatile var none = 0
    @Volatile var other = 0
}
