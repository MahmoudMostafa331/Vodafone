package com.maaki.auto

import kotlinx.coroutines.CompletableDeferred

enum class Outcome { OFFER_SENT, NO_OFFER, TIMEOUT, ERROR }

/** جلسة رقم واحد: الخدمة بتقرأ النافذة وبتكمل النتيجة. */
class Session(
    val number: String,
    val replies: List<String>,
    val noOfferWords: List<String>
) {
    @Volatile var step = 0
    @Volatile var lastMsg = ""
    val result = CompletableDeferred<Pair<Outcome, String>>()
}

object Bridge {
    @Volatile var active: Session? = null
}
