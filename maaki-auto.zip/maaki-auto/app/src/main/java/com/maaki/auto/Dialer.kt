package com.maaki.auto

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

object Dialer {
    /** بيدوّر على شريحة فودافون بالاسم. لو ملقاهاش بيرجّع null ومبنطلبش على شريحة تانية. */
    @Suppress("MissingPermission")
    fun findHandle(ctx: Context, carrierKeys: String): PhoneAccountHandle? {
        val sm = ctx.getSystemService(SubscriptionManager::class.java) ?: return null
        val tm = ctx.getSystemService(TelecomManager::class.java) ?: return null
        val tel = ctx.getSystemService(TelephonyManager::class.java) ?: return null
        val keys = carrierKeys.split("|").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val subs = sm.activeSubscriptionInfoList ?: return null
        val sub = subs.firstOrNull {
            val name = ((it.carrierName?.toString() ?: "") + " " + (it.displayName?.toString() ?: "")).lowercase()
            keys.any { k -> name.contains(k) }
        } ?: return null
        return tm.callCapablePhoneAccounts.firstOrNull {
            tel.createForPhoneAccountHandle(it)?.subscriptionId == sub.subscriptionId
        }
    }

    @Suppress("MissingPermission")
    fun dial(ctx: Context, code: String, handle: PhoneAccountHandle): Boolean {
        return try {
            val tm = ctx.getSystemService(TelecomManager::class.java)
            val extras = Bundle()
            extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
            tm.placeCall(Uri.parse("tel:" + Uri.encode(code)), extras)
            true
        } catch (e: Exception) {
            false
        }
    }
}
