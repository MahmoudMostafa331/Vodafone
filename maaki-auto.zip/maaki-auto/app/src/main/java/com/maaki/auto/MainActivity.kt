package com.maaki.auto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.io.File

class MainActivity : Activity() {

    private lateinit var bases: EditText
    private lateinit var template: EditText
    private lateinit var digits: EditText
    private lateinit var start: EditText
    private lateinit var count: EditText
    private lateinit var delay: EditText
    private lateinit var timeout: EditText
    private lateinit var replies: EditText
    private lateinit var carrier: EditText
    private lateinit var noOffer: EditText
    private lateinit var statusView: TextView
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply { addView(col) }
        setContentView(scroll)

        fun label(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 14f; setPadding(0, 24, 0, 4); gravity = Gravity.START
        })
        fun field(v: String, number: Boolean = false, lines: Int = 1): EditText {
            val e = EditText(this).apply {
                setText(v); textSize = 15f; gravity = Gravity.START
                if (number) inputType = InputType.TYPE_CLASS_NUMBER
                if (lines > 1) { minLines = lines; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
            }
            col.addView(e); return e
        }
        fun btn(t: String, onClick: () -> Unit) = col.addView(Button(this).apply {
            text = t; setOnClickListener { onClick() }
        })

        col.addView(TextView(this).apply { text = "معاكي أوتو"; textSize = 22f; gravity = Gravity.CENTER })

        label("الأرقام الأساسية (رقم في كل سطر، 11 رقم)")
        bases = field(Store.bases, lines = 5)
        label("كود USSD ({N} مكان الرقم)")
        template = field(Store.template)
        label("عدد الخانات المتغيرة من الآخر (1 إلى 8)")
        digits = field(Store.digits.toString(), true)
        label("نقطة بداية التسلسل (1 = الرقم الأساسي +1 في الخانة الأخيرة)")
        start = field(Store.start.toString(), true)
        label("عدد التركيبات لكل رقم أساسي")
        count = field(Store.count.toString(), true)
        label("الانتظار بين كل رقم والتاني (ثواني)")
        delay = field(Store.delaySec.toString(), true)
        label("أقصى انتظار لرد USSD (ثواني)")
        timeout = field(Store.timeoutSec.toString(), true)
        label("الردود المتتابعة في القوائم (بفاصلة) - الافتراضي 1")
        replies = field(Store.replies)
        label("اسم الشركة للشريحة (بـ | بين الأسماء)")
        carrier = field(Store.carrier)
        label("كلمات «مفيش عرض» (بـ | بينها)")
        noOffer = field(Store.noOffer)

        btn("1) إعطاء الصلاحيات") {
            requestPermissions(arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_PHONE_STATE,
                "android.permission.POST_NOTIFICATIONS"), 1)
        }
        btn("2) تفعيل خدمة الوصول (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("بدء جديد (من أول الأرقام)") { start(true) }
        btn("استكمال من آخر نقطة") {
            if (Store.running && Store.paused) { Store.paused = false } else start(false)
        }
        btn("إيقاف مؤقت") { Store.paused = true }
        btn("إيقاف نهائي") {
            startService(Intent(this, RunnerService::class.java).setAction(RunnerService.ACTION_STOP))
        }
        btn("تصدير النتائج (مسح الملف)") {
            val f = File(filesDir, "results.csv")
            Toast.makeText(this, if (f.exists()) f.absolutePath else "مفيش نتائج", Toast.LENGTH_LONG).show()
        }

        statusView = TextView(this).apply { textSize = 15f; setPadding(0, 32, 0, 0); setTextColor(Color.parseColor("#0B5D1E")) }
        col.addView(statusView)
        tick()
    }

    private fun tick() {
        val a11y = if (UssdService.instance != null) "شغالة" else "مش مفعلة"
        statusView.text = "الحالة: ${Store.status}\nالخدمة (Accessibility): $a11y\n" +
            "اتبعت عرض: ${Store.sent} | مفيش عرض: ${Store.none} | أخطاء/مهلة: ${Store.other}"
        ui.postDelayed({ tick() }, 1000)
    }

    private fun save(): Boolean {
        val b = bases.text.toString().lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (b.isEmpty() || b.any { it.length != 11 || !it.all { c -> c.isDigit() } }) {
            toast("الأرقام لازم تكون 11 رقم، رقم في كل سطر"); return false
        }
        val k = digits.text.toString().toIntOrNull() ?: 0
        if (k !in 1..8) { toast("عدد الخانات من 1 إلى 8"); return false }
        if (!template.text.toString().contains("{N}")) { toast("الكود لازم يحتوي {N}"); return false }
        Store.bases = b.joinToString("\n")
        Store.template = template.text.toString().trim()
        Store.digits = k
        Store.start = start.text.toString().toLongOrNull() ?: 1
        Store.count = count.text.toString().toLongOrNull() ?: 10
        Store.delaySec = delay.text.toString().toIntOrNull() ?: 3
        Store.timeoutSec = timeout.text.toString().toIntOrNull() ?: 40
        Store.replies = replies.text.toString().trim()
        Store.carrier = carrier.text.toString().trim()
        Store.noOffer = noOffer.text.toString().trim()
        return true
    }

    private fun start(fresh: Boolean) {
        if (Store.running) { toast("التشغيل شغال بالفعل"); return }
        if (!save()) return
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            toast("اضغط «إعطاء الصلاحيات» الأول"); return
        }
        if (UssdService.instance == null) { toast("فعّل خدمة الوصول الأول"); return }
        if (Dialer.findHandle(this, Store.carrier) == null) {
            toast("ما لقيتش شريحة فودافون، راجع اسم الشركة"); return
        }
        if (fresh) {
            Store.baseIdx = 0; Store.seqN = Store.start; Store.pending = ""
            Store.sent = 0; Store.none = 0; Store.other = 0
            File(filesDir, "results.csv").delete()
        }
        startForegroundService(Intent(this, RunnerService::class.java).setAction(RunnerService.ACTION_START))
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy() }
}
