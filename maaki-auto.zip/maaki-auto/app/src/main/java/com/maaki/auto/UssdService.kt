package com.maaki.auto

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class UssdService : AccessibilityService() {

    companion object {
        @Volatile var instance: UssdService? = null
        private val SEND = setOf("ارسال", "send")
        private val CLOSE = setOf("الغاء", "cancel", "موافق", "ok", "اغلاق", "close", "تم")

        fun norm(t: CharSequence?): String =
            (t?.toString() ?: "").trim().lowercase()
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
    }

    private val h = Handler(Looper.getMainLooper())
    private var ignoreUntil = 0L

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val s = Bridge.active ?: return
        if (s.result.isCompleted) return
        val now = System.currentTimeMillis()
        if (now < ignoreUntil) return

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (!(pkg.contains("phone") || pkg.contains("dialer") ||
                pkg.contains("telecom") || pkg.contains("incallui"))) return

        val texts = ArrayList<String>()
        val buttons = ArrayList<AccessibilityNodeInfo>()
        var input: AccessibilityNodeInfo? = null

        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val cls = n.className?.toString() ?: ""
            val txt = n.text?.toString()
            when {
                n.isEditable || cls.contains("EditText") -> if (input == null) input = n
                cls.contains("Button") || (n.isClickable && !txt.isNullOrBlank()) -> buttons.add(n)
                !txt.isNullOrBlank() -> texts.add(txt)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)

        // نافذة "جاري تنفيذ طلبك" ملهاش أزرار: نتجاهلها ونستنى النافذة الحقيقية
        if (buttons.isEmpty()) return

        val inp = input
        val msg = texts.joinToString("\n")
        if (inp != null && msg == s.lastMsg) return // نفس القائمة لسه ظاهرة، متكررش الرد

        val noOffer = s.noOfferWords.any { it.isNotEmpty() && msg.contains(it) }

        if (inp != null && s.step < s.replies.size && !(s.step == 0 && noOffer)) {
            val reply = s.replies[s.step]
            s.step++
            s.lastMsg = msg
            ignoreUntil = now + 1500
            val send = buttons.firstOrNull { norm(it.text) in SEND }
            if (send == null) {
                closeDialog(buttons)
                s.result.complete(Outcome.ERROR to "مفيش زر إرسال: $msg")
                return
            }
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, reply)
            inp.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            h.postDelayed({ click(send) }, 400)
        } else {
            val outcome = if (s.step == 0 || noOffer) Outcome.NO_OFFER else Outcome.OFFER_SENT
            ignoreUntil = now + 1000
            closeDialog(buttons)
            s.result.complete(outcome to msg)
        }
    }

    private fun click(n: AccessibilityNodeInfo) {
        if (!n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            n.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
    }

    private fun closeDialog(buttons: List<AccessibilityNodeInfo>) {
        val b = buttons.firstOrNull { norm(it.text) in CLOSE }
        if (b != null) click(b) else performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
}
